image1 = 'writing.JPG';
image2 = 'Brickwall.JPG';
I1 = imread(image1);
I2 = imread(image2);
%create the outline and right-click on inside and Create mask
[m,x,y] = roipoly(I1);
%creating a subsquare around the mask
topborder = round(min(y));
bottomborder = round(max(y));
leftborder = round(min(x));
rightborder = round(max(x));
m = m(topborder-1:bottomborder+1, leftborder-1:rightborder+1);
% count the non zero elements
maskpixels = nnz(m);
%same for I1
I1 = I1(topborder-1:bottomborder+1, leftborder-1:rightborder+1,:);
%double click on the interested point (this is where the top left corner of
%the patch will be)
imshow(I2);
[ci,ri] = getpts;
if (~isscalar(ci) || ~isscalar(ri))
    disp("You selected more than one point. Selection not valid");
elseif (ri+size(I1,1)-1>size(I2,1) || ci+size(I1,2)-1>size(I2,2))
    disp("The selected region doesn't fit in target region of the image");
else
    I1 = double(I1);
    I2 = double(I2);

    task3Result = uint8(I2);
    ci = round(ci);
    ri = round(ri);
    % Take the interested region of I2 (f and f*)
    I2 = I2(ri:ri+size(I1,1)-1, ci:ci+size(I1,2)-1,:);
    % this will help with the surrounding pixels N_p
    displacements = [[0,1];[1,0];[0,-1];[-1,0]]; 
    map = zeros(size(I1,1),size(I1,2));
    reversemap = zeros(2,2);
    
    % Creting the sparse matrix of the coefficients A and the product 
    % matrix b.
    A = sparse(maskpixels,maskpixels);
    b_c1 = zeros(maskpixels,1);
    b_c2 = zeros(maskpixels,1);
    b_c3 = zeros(maskpixels,1);
    
    % Unfortunately, matlab's hashmap class does not allow using points as
    % keys. So I had to do make 2 maps of one to get the id of the pixel in
    % Omega and another to get the coordinates of the pixel from the id.
    t = 0;
    for l = 1:size(I1,1)
        for k = 1:size(I1,2)
            if (m(l,k) == 1)
                t = t + 1;            
                map(l,k) = t;
                reversemap(t,1)=l;
                reversemap(t,2)=k;
            end
        end
    end
    for l = 1:size(I1,1)
        for k = 1:size(I1,2)
            if (m(l,k) == 1)
                dm=repmat([l,k],[4,1]) + displacements;
                
                deltaf = zeros(3,1);
                for channel = 1:3
                    % values of f and neighbours N_p
                    % v_pq = g_p - g_q
                    centralpoint = I1(l,k,channel);
                    surpoint1 = I1(dm(1,1),dm(1,2),channel);
                    surpoint2 = I1(dm(2,1),dm(2,2),channel);
                    surpoint3 = I1(dm(3,1),dm(3,2),channel);
                    surpoint4 = I1(dm(4,1),dm(4,2),channel);
                    % div(reversedelta_f(x,y) = 4f(x,y) - sum(f(i,j))
                    deltaf(channel,1) = 4*(centralpoint) - surpoint1 - surpoint2 - surpoint3 - surpoint4;
                end
                
                for q = 1:size(dm,1)                    
                    if m(dm(q,1),dm(q,2))==0
                        % if the point is in the boundary, the points
                        % outside get added to b (sum of f_q*)
                        b_c1(map(l,k))=b_c1(map(l,k))+double(I2(dm(q,1),dm(q,2),1));
                        b_c2(map(l,k))=b_c2(map(l,k))+double(I2(dm(q,1),dm(q,2),2));
                        b_c3(map(l,k))=b_c3(map(l,k))+double(I2(dm(q,1),dm(q,2),3));
                    else
                        % a_pipj = -1 if pj is inside Omega
                        A(map(l,k),map(dm(q,1),dm(q,2)))= -1;
                    end
                end
                % The diagonal of A = N_p which is 4
                A(map(l,k),map(l,k))=4;
                % b += sum of v_pq
                b_c1(map(l,k))=b_c1(map(l,k))+deltaf(1,1);
                b_c2(map(l,k))=b_c2(map(l,k))+deltaf(2,1);
                b_c3(map(l,k))=b_c3(map(l,k))+deltaf(3,1);
            end
        end
    end
% Solve linear system
X_c1 = uint8(A\b_c1);
X_c2 = uint8(A\b_c2);
X_c3 = uint8(A\b_c3);

% Retrace onto the new image
for t = 1:length(X_c1)
    task3Result(ri+reversemap(t,1),ci+reversemap(t,2),1) = X_c1(t);
    task3Result(ri+reversemap(t,1),ci+reversemap(t,2),2) = X_c2(t);
    task3Result(ri+reversemap(t,1),ci+reversemap(t,2),3) = X_c3(t);
end
imshow(task3Result);
end