function [ii] = computeIntegralImage(image)

%REPLACE THIS
image = rgb2gray(image);
image = padarray(image,[1,1],0,'pre');
image = double(image);
ii = cumsum(cumsum(image,2),1);

end