function [result] = nonLocalMeans(image, sigma, h, patchSize, searchWindowSize, improve)

%REPLACE THIS
    windowRadius = searchWindowSize;
    windowSize = 2*windowRadius+1;
    image = double(image);

    [m,n,dim] = size(image);
    % Sanitizing the input
    if (patchSize>windowRadius)
        warning('Your patchSize is bigger than the search window');
    end
    if ((2*windowRadius+1)>m || (2*windowRadius+1)>n)
        error('WindowSize not admissible');
    end
    if(patchSize == 0 || windowRadius == 0)
        error('patchSize or windowRadius not admissible');
    end

    % Creating better manageable variables
    pixelsInWindow = windowSize^2;
    % Initializing arrays for offsets
    offsetsRows = zeros(pixelsInWindow,1);
    offsetsCols = zeros(pixelsInWindow,1);
    z= 1;
    % Saving values for indexing arrays
    while z < pixelsInWindow
        for x = -windowRadius:windowRadius
            for y = -windowRadius:windowRadius
                offsetsRows(z,1) = x;
                offsetsCols(z,1) = y;
                z = z+1;
            end
        end
    end
    
    % Initializing array for the results
    result = zeros(size(image));
    % Integral method
    if improve == true
        % Converting to double and initializing for weights
        image = im2double(image);
        sumWeight = ones(m,n);
        weightedImage = zeros(m,n,dim);
        % Getting the crop for each type of sector of the image
        for t = 1:pixelsInWindow
            if(offsetsRows(t,1)>0 && offsetsCols(t,1)>0)
                patch1 = imcrop(image,[offsetsRows(t,1) offsetsCols(t,1) n-offsetsRows(t,1) m-offsetsCols(t,1)]);
                patch2 = imcrop(image,[1 1 n-offsetsRows(t,1) m-offsetsCols(t,1)]);
            elseif(offsetsRows(t,1)<0 && offsetsCols(t,1)<0)
                patch1 = imcrop(image,[1 1 n+offsetsRows(t,1) m+offsetsCols(t,1)]);
                patch2 = imcrop(image,[-offsetsRows(t,1) -offsetsCols(t,1) n+offsetsRows(t,1) m+offsetsCols(t,1)]);
            elseif(offsetsRows(t,1)>0 && offsetsCols(t,1)<0)
                patch1 = imcrop(image,[offsetsRows(t,1) 1 n-offsetsRows(t,1) m+offsetsCols(t,1)]);
                patch2 = imcrop(image,[1 -offsetsCols(t,1) n-offsetsRows(t,1) m+offsetsCols(t,1)]);
            elseif(offsetsRows(t,1)<0 && offsetsCols(t,1)>0)
                patch1 = imcrop(image,[1 offsetsCols(t,1) n+offsetsRows(t,1) m-offsetsCols(t,1)]);
                patch2 = imcrop(image,[-offsetsRows(t,1) 1 n+offsetsRows(t,1) m-offsetsCols(t,1)]);
            elseif(offsetsRows(t,1)==0 && offsetsCols(t,1)==0)
                patch1 = imcrop(image,[1 offsetsCols(t,1) n+offsetsRows(t,1) m-offsetsCols(t,1)]);
                patch2 = imcrop(image,[-offsetsRows(t,1) 1 n+offsetsRows(t,1) m-offsetsCols(t,1)]);
            end
            patch1 = double(patch1);
            patch2 = double(patch2);
            % Calculating the difference image and its integral image
            diffImage = imabsdiff(patch1,patch2).^2;
            integralImage = computeIntegralImage(diffImage);
            [intRows,intCols,dim] = size(integralImage);
            
            % For each pixel in the image calculate calculate the patch in
            % the integral image and its corresponding weight
            for row = 1:m
                for col = 1:n
                    if (row+offsetsRows(t,1) >=1 && row+offsetsRows(t,1)<m && col+offsetsCols(t,1) >=1 && col+offsetsCols(t,1)<n)
                    if (row+patchSize < intRows && row-patchSize >=1 && col+patchSize < intCols && col-patchSize >=1)
                        L1 = integralImage(row-patchSize, col-patchSize);
                        L2 = integralImage(row+patchSize, col-patchSize);
                        L3 = integralImage(row+patchSize, col+patchSize);
                        L4 = integralImage(row-patchSize, col+patchSize);
                        ssd= (L3+L1-L2-L4);
                        %disp(['row', num2str(row), ' col ', num2str(col), ' t ', num2str(t),' r+o ' , num2str(row+offsetsRows(t,1)), ' col+o ', num2str(col+offsetsCols(t,1))]);
                        weight = exp(-max((ssd)-(2*(sigma^2)),0)/(h^2));
                        if sumWeight(row,col) == 1
                            sumWeight(row,col) = weight;
                        else
                            sumWeight(row,col) = sumWeight(row,col)+weight;
                        end
                        % Apply the weights to the weightedMatrix
                        weightedImage(row,col,:) = weightedImage(row,col,:) + double(image(row+offsetsRows(t,1),col+offsetsCols(t,1),:))*weight;
                    end
                    end
                end
            end
        end
        % Make sure the weights sum up to 1 by dividing by the sum of the
        % weigths and add to the result
        weightedImage = weightedImage./sumWeight;
        % Transform into uint8
        weightedImage = uint8(255*(weightedImage - min(weightedImage(:))) / (max(weightedImage(:)) - min(weightedImage(:))));
        result = uint8(result);
        result= result + weightedImage;
    else
        % Naive method
        % Initialize the arrays and variables
        image = im2double(image);
        sigma = sigma/(3*(2*patchSize+1));
        extrabit = patchSize+windowRadius;
        paddedimage = padarray(image,[extrabit,extrabit],0,'both');
        sumWeight = ones(m,n);
        %distances = zeros(pixelsInWindow,1);
        % for each of the pixels in the image excluding the padding
        for row = 1+extrabit:m+extrabit
            for col = 1+extrabit:n+extrabit       
                % Get the patch at the pixel of interest 
                centralPatch = imcrop(paddedimage,[(col-patchSize) (row-patchSize) (2*patchSize) (2*patchSize)]);
                % Get the patches at the offsets
                for z = 1:pixelsInWindow
                    newx = row+offsetsRows(z,1)-patchSize;
                    newy = col+offsetsCols(z,1)-patchSize;
                    tempPatch = imcrop(paddedimage,[newy newx (2*patchSize) (2*patchSize)]);                        
                    [tempm,tempn,dim] = size(tempPatch);
                    [centm,centn,dim] = size(tempPatch);
                    % Calculate the difference between the patches and
                    % normalize
                    differenceImage = centralPatch - tempPatch;
                    ssd = sum(differenceImage(:).^2)/(3*(2*patchSize+1));
                    % Calculate the weight for each sum of the squared
                    % distances
                    w = exp(-max((ssd)-(2*sigma^2),0)/(h^2));
                    if sumWeight(row-extrabit,col-extrabit) == 1
                        sumWeight(row-extrabit,col-extrabit) = w;
                    else
                        sumWeight(row-extrabit,col-extrabit) = sumWeight(row-extrabit,col-extrabit)+w;
                    end
                    %Add to the result
                    result(row-extrabit,col-extrabit,:)= result(row-extrabit,col-extrabit,:) + w*paddedimage(1+row-windowRadius+offsetsRows(z,1),1+col-windowRadius+offsetsCols(z,1),:);
                end
            end
        end
        %result = result./sumWeight;
        % Transform into uint8
        result = uint8(255*(result - min(result(:))) / (max(result(:)) - min(result(:))));
    end
end