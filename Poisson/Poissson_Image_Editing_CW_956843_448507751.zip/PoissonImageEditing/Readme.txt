-The files are organized per task as described in google docs coursework text.
-Inside the files are the results of each task.
-I do not own any of the images which I have found either by googling them or 
 capturing them from the provided material.
-I tried reproducing the effect of child in the beach but the lines painted on the target
 did not allow for the exact same result.
-Sources for extra information:
https://www.youtube.com/watch?v=UcTJDamstdk&t=2073s
https://www.comp.nus.edu.sg/~tsim/documents/Compositing_CAIP09.pdf
https://sandipanweb.wordpress.com/2017/10/03/some-variational-image-processing-possion-image-editing-and-its-applications/
