image1 = 'Flying-birds.JPG';
I1 = imread(image1);
%this is only for the grayscale task
I1 = rgb2gray(I1);
%create the outline and right-click on inside and Create mask
[m,x,y] = roipoly(I1);

task1Result = I1;
%creating a subsquare around the mask
topborder = round(min(y));
bottomborder = round(max(y));
leftborder = round(min(x));
rightborder = round(max(x));
m = m(topborder-1:bottomborder+1, leftborder-1:rightborder+1);
% count the non zero elements
maskpixels = nnz(m);
%same for I1
I1 = I1(topborder-1:bottomborder+1, leftborder-1:rightborder+1,:);

displacements = [[0,1];[1,0];[0,-1];[-1,0]];
map = zeros(size(I1,1),size(I1,2));
reversemap = zeros(2,2);

A = sparse(maskpixels,maskpixels);
b = zeros(maskpixels,1);

t = 0;
for l = 1:size(I1,1)
    for k = 1:size(I1,2)
        if (m(l,k) == 1)
            t = t + 1;            
            map(l,k) = t;
            reversemap(t,1)=l;
            reversemap(t,2)=k;
        end
    end
end

for l = 1:size(I1,1)
    for k = 1:size(I1,2)
        if (m(l,k) == 1)         
            dm=repmat([l,k],[4,1]) + displacements;
            for q = 1:size(dm,1)
                if m(dm(q,1),dm(q,2))==0
                    b(map(l,k))=b(map(l,k))+double(I1(dm(q,1),dm(q,2)));
                else
                    A(map(l,k),map(dm(q,1),dm(q,2)))= -1;
                end
            end
            A(map(l,k),map(l,k))=4;
        end
    end
end

X = A\b;

for t = 1:length(X)
    task1Result(topborder-1+reversemap(t,1),leftborder-1+reversemap(t,2)) = X(t);
end
imshow(mat2gray(task1Result));