function [ii] = computeIntegralImage(image)

%REPLACE THIS
ii = zeros(size(image));

end