function [offsetsRows, offsetsCols, distances] = templateMatchingIntegralImage(row,...
    col,patchSize, searchWindowSize, image)
% This function should for each possible offset in the search window
% centred at the current row and col, save a value for the offsets and
% patch distances, e.g. for the offset (-1,-1)
% offsetsX(1) = -1;
% offsetsY(1) = -1;
% distances(1) = 0.125;

% The distance is simply the SSD over patches of size patchSize between the
% 'template' patch centred at row and col and a patch shifted by the
% current offset

% This time, use the integral image method!
% NOTE: Use the 'computeIntegralImage' function developed earlier to
% calculate your integral images
% NOTE: Use the 'evaluateIntegralImage' function to calculate patch sums

%REPLACE THIS
    windowRadius = searchWindowSize;
    windowSize = 2*windowRadius+1;
    image = im2double(image);

    [m,n,dim] = size(image);
    % Sanitizing the input
    if (patchSize>windowRadius)
        warning('Your patchSize is bigger than the search window');
    end
    if ((2*windowRadius+1)>m || (2*windowRadius+1)>n)
        error('WindowSize not admissible');
    end
    if(patchSize == 0 || windowRadius == 0)
        error('patchSize or windowRadius not admissible');
    end
    % Creating better manageable variables
    pixelsInWindow = windowSize^2;
    % Initializing arrays for offsets
    offsetsRows = zeros(pixelsInWindow,1);
    offsetsCols = zeros(pixelsInWindow,1);
    z= 1;
    % Saving values for indexing arrays
    while z < pixelsInWindow
        for x = -windowRadius:windowRadius
            for y = -windowRadius:windowRadius
                offsetsRows(z,1) = x;
                offsetsCols(z,1) = y;
                z = z+1;
            end
        end
    end
    % Initializing array for the results
    distances = zeros(pixelsInWindow, 1);
    % Getting the crop for each type of sector of the image
    for t = 1:pixelsInWindow
        %centralImage = padarray(image, [], 0,)
            if(offsetsRows(t,1)>0 && offsetsCols(t,1)>0)
                patch1 = imcrop(image,[offsetsRows(t,1) offsetsCols(t,1) n-offsetsRows(t,1) m-offsetsCols(t,1)]);
                patch2 = imcrop(image,[1 1 n-offsetsRows(t,1) m-offsetsCols(t,1)]);
            elseif(offsetsRows(t,1)<0 && offsetsCols(t,1)<0)
                patch1 = imcrop(image,[1 1 n+offsetsRows(t,1) m+offsetsCols(t,1)]);
                patch2 = imcrop(image,[-offsetsRows(t,1) -offsetsCols(t,1) n+offsetsRows(t,1) m+offsetsCols(t,1)]);
            elseif(offsetsRows(t,1)>0 && offsetsCols(t,1)<0)
                patch1 = imcrop(image,[offsetsRows(t,1) 1 n-offsetsRows(t,1) m+offsetsCols(t,1)]);
                patch2 = imcrop(image,[1 -offsetsCols(t,1) n-offsetsRows(t,1) m+offsetsCols(t,1)]);
            elseif(offsetsRows(t,1)<0 && offsetsCols(t,1)>0)
                patch1 = imcrop(image,[1 offsetsCols(t,1) n+offsetsRows(t,1) m-offsetsCols(t,1)]);
                patch2 = imcrop(image,[-offsetsRows(t,1) 1 n+offsetsRows(t,1) m-offsetsCols(t,1)]);
            elseif(offsetsRows(t,1)==0 && offsetsCols(t,1)==0)
                patch1 = imcrop(image,[1 offsetsCols(t,1) n+offsetsRows(t,1) m-offsetsCols(t,1)]);
                patch2 = imcrop(image,[-offsetsRows(t,1) 1 n+offsetsRows(t,1) m-offsetsCols(t,1)]);
            end
            %disp([' t:' ,num2str(t)]);
            %disp([' offsetR:' ,num2str(offsetsRows(t,1)), ' offsetC:' ,num2str(offsetsCols(t,1))]);
            % Calculating the difference image and its integral image
            dif = (patch1 - patch2);
            imshow(dif);
            ssd = dif.^2;
    %         for c = 1:3
    %             integralImage = computeIntegralImage(ssd(:,:,c));
    %             L1 = integralImage(row-round(patchSize/2), col-round(patchSize/2));
    %             L2 = integralImage(row+round(patchSize/2), col-round(patchSize/2));
    %             L3 = integralImage(row+round(patchSize/2), col+round(patchSize/2));
    %             L4 = integralImage(row-round(patchSize/2), col+round(patchSize/2));
    %             distances(t,1)= distances(t,1) + (L3+L1-L2-L4);
    %         end
            integralImage = computeIntegralImage(ssd);
            %Getting the values of the patch in the integral image
            L1 = integralImage(row-patchSize, col-patchSize);
            L2 = integralImage(row+patchSize, col-patchSize);
            L3 = integralImage(row+patchSize, col+patchSize);
            L4 = integralImage(row-patchSize, col+patchSize);
            distances(t,1)= (L3+L1-L2-L4);
        
    end

end