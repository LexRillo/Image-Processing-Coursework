function [result] = nonLocalMeans(image, sigma, h, patchSize, windowSize)

%REPLACE THIS
result = zeros(size(image));

end