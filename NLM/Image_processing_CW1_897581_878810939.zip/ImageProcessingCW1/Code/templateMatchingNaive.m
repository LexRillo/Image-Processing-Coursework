function [offsetsRows, offsetsCols, distances] = templateMatchingNaive(row, col,...
    patchSize, searchWindowSize, image)

% This function should for each possible offset in the search window
% centred at the current row and col, save a value for the offsets and
% patch distances, e.g. for the offset (-1,-1)
% offsetsRows(1) = -1;
% offsetsCols(1) = -1;
% distances(1) = 0.125;

% The distance is simply the SSD over patches of size patchSize between the
% 'template' patch centred at row and col and a patch shifted by the
% current offset

%REPLACE THIS
    %Initialization
    windowRadius = searchWindowSize;
    windowSize = 2*windowRadius+1;
    image = im2double(image);

    [m,n,dim] = size(image);
    % Sanitizing the input
    if (patchSize>windowRadius)
        warning('Your patchSize is bigger than the search window');
    end
    if ((2*windowRadius+1)>m || (2*windowRadius+1)>n)
        error('WindowSize not admissible');
    end
    if(patchSize == 0 || windowRadius == 0)
        error('patchSize or windowRadius not admissible');
    end
    % Creating better manageable variables
    pixelsInWindow = windowSize^2;
    % Initializing arrays for offsets
    offsetsRows = zeros(pixelsInWindow,1);
    offsetsCols = zeros(pixelsInWindow,1);
    % Saving values for indexing arrays
    z= 1;
    while z < pixelsInWindow
        for x = -windowRadius:windowRadius
            for y = -windowRadius:windowRadius
                offsetsRows(z,1) = x;
                offsetsCols(z,1) = y;
                z = z+1;
            end
        end
    end

    extrabit = patchSize+windowRadius;
    paddedimage = padarray(image,[extrabit,extrabit],0,'both');
    distances = zeros(pixelsInWindow,1);
    % Get the patch at the pixel of interest 
    centralPatch = imcrop(paddedimage,[(row-patchSize) (col-patchSize) (2*patchSize) (2*patchSize)]);
    % Get the patches at the offsets
    for z = 1:pixelsInWindow
        newx = row+offsetsRows(z,1)-patchSize;
        newy = col+offsetsCols(z,1)-patchSize;
        tempPatch = imcrop(paddedimage,[newx newy (2*patchSize) (2*patchSize)]);
        % Calculate the difference between the patches and
        % normalize
        differenceImage = centralPatch - tempPatch;
        ssd = sum(differenceImage(:).^2)/(3*(2*patchSize+1));
        distances(z,1)= ssd;
    end
end